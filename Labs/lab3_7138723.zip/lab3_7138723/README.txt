Student name:   Felix Chiasson
Student number: 7138723
Class:          ITI1521A
Lab section:    3
Description:    This archive contains Utils.java, TestFindAndReplace.java,
                and an unfinished version of Rational.java. The answer
                to the quiz is 'Vrai'.
