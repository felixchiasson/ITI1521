/*************************************************************************************************
*     File Name           :     Utils.java
*     Created By          :     Felix Chiasson (7138723)
*     Creation Date       :     [2016-02-02 19:20]
*     Last Modified       :     [2016-02-04 22:19]
*     Description         :
**************************************************************************************************/

public class Utils {

  /**
   * Finds a specified string inside a list of words and replaces it with another.
   * @param in is the original string
   * @param what is the queried string
   * @param with is the replacement string
   **/

    public static String[] findAndReplace(String[] in, String[] what, String[] with) {
        int i, j;
        if((in==null)||(what==null)||(with==null)) {
            return null;
        } else if(what.length != with.length) {
            return null;
        } else {
          String[] out = new String[in.length];
            for(i = 0; i < in.length; i++) {
              if(in[i] == null) {
                return null;
              } else if(what.length >= 1 && with.length >= 1){
                for(j = 0; j < what.length; j++) {
                    if(what[j] == null || with[j] == null) {
                        return null;
                    } else if(in[i].equals(what[j])) {
                        out[i] = with[j];
                        break;
                    } else {
                        out[i] = in[i];

                    }
                }
              } else {
                return in;
              }

        }
            return out;
    }
    }
}
