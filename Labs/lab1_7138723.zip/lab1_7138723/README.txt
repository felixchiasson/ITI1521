Student name: Felix Chiasson
Student number: 7138723
Course code: ITI1521
Lab Section: Mardi (3)

This archive contains 5 files of the lab 1, that is this file (README.txt), the
file Command.java in directory Q1 and versions of ArrayTool.java corresponding
to questions 2 to 4 in directories Q2, Q3, Q4.
