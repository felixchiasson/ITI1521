Noms:               Felix Chiasson et Sofiane Bouabdallah
Numéro Étudiant:    7138723           8156256
Section du cours:   ITI1521A
Description:        Implémentation en Java d'un jeu dont le but est
                    d'emprisoner une bille bleue en sélectionnant des billes
                    grises afin d'empêcher la bille bleue d'atteindre le bord
                    de la grille de jeu. Le code source comprends un fichier
                    data contenant les images utilisées pour l'interface
                    graphique, un controlleur GameController.java implémentant
                    la logique du jeu, un modèle GameModel.java implémentant le
                    modèle du jeu et un vue GameView.java implémentant
                    l'interface graphique du jeu. Ces classes sont accompagnées
                    des sous-classes DotButton.java, BoardView.java et
                    Point.java. CircleTheDot.java contient la méthode main.
