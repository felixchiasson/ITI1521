Noms:               Felix Chiasson et Sofiane Bouabdallah
Numéro Étudiant:    7138723           8156256
Section du cours:   ITI1521A
Description:        Version améliorée du devoir 2 du cours ITI1521. Better
                    exception handling, use of clonage in order to implement
                    the ability to undo and redo moves at whim. As a bonus, the
                    game will now save to the disk when the user uses the Quit
                    button. Running the application will try to load the save
                    file - if it does not succeed, the game starts from
                    scratch.
