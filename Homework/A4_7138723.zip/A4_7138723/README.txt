Noms:               Felix Chiasson et Sofiane Bouabdallah
Numéro Étudiant:    7138723           8156256
Section du cours:   ITI1521A
Description:        Réponses aux questions du devoir 4.
