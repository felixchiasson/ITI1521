Noms:               Felix Chiasson et Sofiane Bouabdallah
Numéros étudiants:  7138723           8156256
Section du cours:   ITI1521A
Description:        Trois portes se présentent à l'utilisateur. Derrière l'une
                    d'entres elles se trouve un prix, alors que les deux autres
                    portes sont vides. L'utilisateur doit choisir une porte - un
                    animateur ouvre alors une autre porte vide et demande à
                    l'utilisateur s'il désire changer de porte. Ceci est une
                    implémentation en Java du jeu Monty Hall.
